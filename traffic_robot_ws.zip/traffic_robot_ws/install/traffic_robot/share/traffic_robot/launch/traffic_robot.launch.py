import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node

def generate_launch_description():

    world_file = os.path.expanduser(
        '~/traffic_robot_ws/src/traffic_robot/worlds/traffic_world.sdf')
    robot_sdf  = os.path.expanduser(
        '~/traffic_robot_ws/src/traffic_robot/urdf/robot.sdf')

    # 1. Launch Gazebo with our world
    gazebo = ExecuteProcess(
        cmd=['gz', 'sim', '-r', world_file],
        output='screen'
    )

    # 2. Spawn robot into Gazebo (after 5 seconds)
    spawn_robot = TimerAction(
        period=5.0,
        actions=[
            ExecuteProcess(
                cmd=[
                    'gz', 'service',
                    '-s', '/world/traffic_world/create',
                    '--reqtype', 'gz.msgs.EntityFactory',
                    '--reptype', 'gz.msgs.Boolean',
                    '--timeout', '5000',
                    '--req',
                    f'sdf_filename: "{robot_sdf}", name: "traffic_robot"'
                ],
                output='screen'
            )
        ]
    )

    # 3. ROS-GZ bridge for cmd_vel
    bridge = TimerAction(
        period=8.0,
        actions=[
            ExecuteProcess(
                cmd=[
                    'ros2', 'run', 'ros_gz_bridge', 'parameter_bridge',
                    '/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist'
                ],
                output='screen'
            )
        ]
    )

    # 4. Robot controller node (after bridge)
    robot_controller = TimerAction(
        period=10.0,
        actions=[
            Node(
                package='traffic_robot',
                executable='robot_controller',
                name='robot_controller',
                output='screen'
            )
        ]
    )

    return LaunchDescription([
        gazebo,
        spawn_robot,
        bridge,
        robot_controller,
    ])
