#!/usr/bin/env python3
"""
sign_detector.py
Detects traffic signs using:
  1. YOLO (ML model) — primary detector
  2. OpenCV shape + color — fallback / complementary detector
Publishes command strings to /traffic_sign topic.
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import cv2
import numpy as np
import threading
import time
import os

# ─────────────────────────────────────────────
#  YOLO  (optional — loads best available .pt)
# ─────────────────────────────────────────────
LOCAL_MODEL = None
try:
    from ultralytics import YOLO
    pt_candidates = [
        os.path.expanduser('~/best.pt'),
        os.path.expanduser('~/traffic_best.pt'),
        os.path.expanduser('~/runs/detect/traffic_sign_model/weights/best.pt'),
        os.path.expanduser('~/yolov8n.pt'),
    ]
    for pt in pt_candidates:
        if os.path.exists(pt):
            LOCAL_MODEL = YOLO(pt)
            print(f"[YOLO] Model loaded: {pt}")
            break
    if LOCAL_MODEL is None:
        LOCAL_MODEL = YOLO('yolov8n.pt')
        print("[YOLO] Using base yolov8n")
except Exception as e:
    print(f"[YOLO] Not available: {e}")

# ─────────────────────────────────────────────
#  Label → command map  (YOLO class names)
# ─────────────────────────────────────────────
SIGN_MAP = {
    'Stop_Sign':                   'STOP',
    'No-Entry':                    'STOP',
    'stop sign':                   'STOP',
    'Give-Way':                    'GO',
    'one way':                     'GO',
    'Pass either side':            'GO',
    'traffic light':               'GO',
    'Left-Only':                   'LEFT',
    'no left turn':                'LEFT',
    'Keep-Left':                   'LEFT',
    'Dangerous-Left-Curve-Ahead':  'LEFT',
    'Right-Only':                  'RIGHT',
    'no right turn':               'RIGHT',
    'Keep-Right':                  'RIGHT',
    'Dangerous-Right-Curve-Ahead': 'RIGHT',
    '20-speed-limit':              'SLOW',
    '40-speed-limit':              'SLOW',
    '60-speed-limit':              'SLOW',
    '80-speed-limit':              'SLOW',
    '110-speed-limit':             'SLOW',
    'traffic lights ahead':        'WAIT',
    'No-Parking-Or-Standing':      'WAIT',
    'No-U-turn':                   'WAIT',
}

# ─────────────────────────────────────────────
#  HSV colour ranges for OpenCV detector
# ─────────────────────────────────────────────
HSV_RANGES = {
    'red':    [(np.array([0,   120, 70]),  np.array([10,  255, 255])),
               (np.array([170, 120, 70]),  np.array([180, 255, 255]))],
    'green':  [(np.array([40,  70,  70]),  np.array([90,  255, 255]))],
    'yellow': [(np.array([20,  100, 100]), np.array([35,  255, 255]))],
    'blue':   [(np.array([100, 100, 50]),  np.array([130, 255, 255]))],
}

# ─────────────────────────────────────────────
#  Shape + colour → command rules
#  GO   → green circle
#  WAIT → yellow triangle
#  STOP → red octagon or red circle
#  SLOW → yellow circle
#  GO   → blue rectangle (directional sign)
# ─────────────────────────────────────────────
SHAPE_RULES = {
    ('green',  'circle'):    'GO',
    ('red',    'octagon'):   'STOP',
    ('red',    'circle'):    'STOP',
    ('yellow', 'triangle'):  'WAIT',
    ('yellow', 'circle'):    'SLOW',
    ('blue',   'rectangle'): 'GO',
}

CMD_COLORS = {
    'GO':    (0, 255, 0),
    'STOP':  (0, 0, 255),
    'LEFT':  (255, 165, 0),
    'RIGHT': (0, 165, 255),
    'SLOW':  (0, 255, 255),
    'WAIT':  (255, 0, 255),
}

# ─────────────────────────────────────────────
#  Classify contour by vertex count
# ─────────────────────────────────────────────
def classify_shape(contour):
    peri   = cv2.arcLength(contour, True)
    approx = cv2.approxPolyDP(contour, 0.03 * peri, True)
    verts  = len(approx)
    if verts == 3:
        return 'triangle'
    elif verts == 4:
        (x, y, w, h) = cv2.boundingRect(approx)
        ar = w / float(h)
        return 'square' if 0.9 <= ar <= 1.1 else 'rectangle'
    elif verts == 5:
        return 'pentagon'
    elif verts == 6:
        return 'hexagon'
    elif verts == 8:
        return 'octagon'
    elif verts > 8:
        area       = cv2.contourArea(contour)
        (_, r)     = cv2.minEnclosingCircle(contour)
        if r > 0 and (area / (np.pi * r * r)) > 0.75:
            return 'circle'
        return 'polygon'
    return 'unknown'

# ─────────────────────────────────────────────
#  OpenCV detector
# ─────────────────────────────────────────────
def detect_opencv(frame):
    results  = []
    hsv      = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    h, w     = frame.shape[:2]
    min_area = (h * w) * 0.003

    for colour, ranges in HSV_RANGES.items():
        mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
        for (lo, hi) in ranges:
            mask = cv2.bitwise_or(mask, cv2.inRange(hsv, lo, hi))
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
        mask   = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  kernel)
        mask   = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL,
                                        cv2.CHAIN_APPROX_SIMPLE)
        for cnt in contours:
            if cv2.contourArea(cnt) < min_area:
                continue
            shape   = classify_shape(cnt)
            command = SHAPE_RULES.get((colour, shape))
            if command is None:
                continue
            (x, y, bw, bh) = cv2.boundingRect(cnt)
            results.append({
                'class':      f'{colour}_{shape}',
                'command':    command,
                'confidence': 0.70,
                'x': x + bw//2, 'y': y + bh//2,
                'width': bw, 'height': bh,
                'source': 'opencv'
            })
    return results

# ─────────────────────────────────────────────
#  YOLO detector
# ─────────────────────────────────────────────
def detect_yolo(frame, logger=None):
    if LOCAL_MODEL is None:
        return []
    try:
        results = LOCAL_MODEL(frame, verbose=False, conf=0.35)
        preds   = []
        for r in results:
            for box in r.boxes:
                cls_id       = int(box.cls[0])
                conf         = float(box.conf[0])
                name         = LOCAL_MODEL.names[cls_id]
                x1,y1,x2,y2 = box.xyxy[0].tolist()
                preds.append({
                    'class':      name,
                    'command':    SIGN_MAP.get(name, 'STOP'),
                    'confidence': conf,
                    'x': (x1+x2)/2, 'y': (y1+y2)/2,
                    'width':  x2-x1, 'height': y2-y1,
                    'source': 'yolo'
                })
        return preds
    except Exception as e:
        if logger:
            logger.warn(f'YOLO error: {e}')
        return []

# ─────────────────────────────────────────────
#  Merge: YOLO wins over overlapping CV result
# ─────────────────────────────────────────────
def merge_predictions(yolo_preds, cv_preds):
    if not yolo_preds:
        return cv_preds
    merged = list(yolo_preds)
    for cv_p in cv_preds:
        overlaps = False
        for yp in yolo_preds:
            dx = abs(cv_p['x'] - yp['x'])
            dy = abs(cv_p['y'] - yp['y'])
            if dx < (cv_p['width']  + yp['width'])  / 2 and \
               dy < (cv_p['height'] + yp['height']) / 2:
                overlaps = True
                break
        if not overlaps:
            merged.append(cv_p)
    return merged

# ─────────────────────────────────────────────
#  Draw bounding boxes + command banner
#  + visual shape indicator (top-right corner)
# ─────────────────────────────────────────────
def draw_overlay(frame, predictions, command):
    color = CMD_COLORS.get(command, (255, 255, 255))

    # Bounding boxes
    for pred in predictions:
        x  = int(pred['x'] - pred['width']  / 2)
        y  = int(pred['y'] - pred['height'] / 2)
        bw = int(pred['width'])
        bh = int(pred['height'])
        cv2.rectangle(frame, (x, y), (x+bw, y+bh), color, 2)
        cv2.putText(frame,
                    f"{pred['class']} {pred['confidence']:.2f} [{pred.get('source','?')}]",
                    (x, y-8), cv2.FONT_HERSHEY_SIMPLEX, 0.50, color, 2)

    # Semi-transparent command banner
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (340, 70), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.55, frame, 0.45, 0, frame)
    cv2.putText(frame, f'CMD: {command}',
                (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.5, color, 3)

    # Visual indicator — top-right corner
    ih, iw = frame.shape[:2]
    cx, cy, r = iw - 80, 80, 45

    if command == 'GO':
        # Green filled circle
        cv2.circle(frame, (cx, cy), r, (0, 255, 0), -1)
        cv2.circle(frame, (cx, cy), r, (0, 180, 0),  3)
        cv2.putText(frame, 'GO', (cx-22, cy+10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 0), 2)

    elif command == 'WAIT':
        # Yellow upward triangle
        pts = np.array([
            [cx,     cy - r],
            [cx - r, cy + r],
            [cx + r, cy + r]
        ], dtype=np.int32)
        cv2.fillPoly(frame,  [pts], (0, 215, 255))
        cv2.polylines(frame, [pts], True, (0, 160, 200), 3)
        cv2.putText(frame, 'WAIT', (cx-30, cy+20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 2)

    elif command == 'STOP':
        # Red octagon
        angles = [np.pi/8 + i * np.pi/4 for i in range(8)]
        pts = np.array([[int(cx + r*np.cos(a)), int(cy + r*np.sin(a))]
                        for a in angles], dtype=np.int32)
        cv2.fillPoly(frame,  [pts], (0, 0, 220))
        cv2.polylines(frame, [pts], True, (0, 0, 160), 3)
        cv2.putText(frame, 'STOP', (cx-30, cy+10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)

    elif command == 'SLOW':
        # Yellow circle
        cv2.circle(frame, (cx, cy), r, (0, 215, 255), -1)
        cv2.circle(frame, (cx, cy), r, (0, 160, 200),  3)
        cv2.putText(frame, 'SLOW', (cx-28, cy+10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 0, 0), 2)

    elif command in ('LEFT', 'RIGHT'):
        # Blue rectangle with arrow
        cv2.rectangle(frame, (cx-r, cy-r//2), (cx+r, cy+r//2), (200, 120, 0), -1)
        cv2.rectangle(frame, (cx-r, cy-r//2), (cx+r, cy+r//2), (150, 90,  0),  3)
        d = 1 if command == 'RIGHT' else -1
        cv2.arrowedLine(frame,
                        (cx - d*20, cy), (cx + d*30, cy),
                        (255, 255, 255), 3, tipLength=0.4)

    return frame

# ─────────────────────────────────────────────
#  ROS 2 Node
# ─────────────────────────────────────────────
class SignDetector(Node):
    def __init__(self):
        super().__init__('sign_detector')
        self.publisher    = self.create_publisher(String, '/traffic_sign', 10)
        self.current_sign = 'STOP'
        self.predictions  = []
        self.cap          = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            self.get_logger().error('Cannot open camera!')
        self.running     = True
        self.frame_count = 0
        self.thread      = threading.Thread(target=self.detection_loop, daemon=True)
        self.thread.start()
        self.get_logger().info('Sign Detector Started! (YOLO + OpenCV)')

    def get_command(self, predictions):
        if not predictions:
            return 'STOP'
        best = max(predictions, key=lambda x: x.get('confidence', 0))
        self.get_logger().info(
            f"Best: {best['class']}  conf={best['confidence']:.2f}"
            f"  src={best.get('source','?')}  cmd={best['command']}"
        )
        return best['command']

    def detection_loop(self):
        while self.running:
            ret, frame = self.cap.read()
            if not ret:
                time.sleep(0.05)
                continue
            self.frame_count += 1

            if self.frame_count % 10 == 0:
                yolo_preds        = detect_yolo(frame, self.get_logger())
                cv_preds          = detect_opencv(frame)
                self.predictions  = merge_predictions(yolo_preds, cv_preds)
                self.current_sign = self.get_command(self.predictions)
                msg      = String()
                msg.data = self.current_sign
                self.publisher.publish(msg)

            frame = draw_overlay(frame, self.predictions, self.current_sign)
            cv2.imshow('Traffic Sign Detector', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                self.running = False
                break

        self.cap.release()
        cv2.destroyAllWindows()

    def destroy_node(self):
        self.running = False
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = SignDetector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
