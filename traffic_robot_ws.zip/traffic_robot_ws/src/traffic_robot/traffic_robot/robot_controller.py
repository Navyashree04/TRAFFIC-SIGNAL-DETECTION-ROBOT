#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import threading
import time

class RobotController(Node):
    def __init__(self):
        super().__init__('robot_controller')
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.sign_sub = self.create_subscription(
            String, '/traffic_sign',
            self.sign_callback, 10)
        self.current_command = 'STOP'
        self.waiting = False
        self.timer = self.create_timer(0.1, self.control_loop)
        self.get_logger().info('Robot Controller Started!')

    def sign_callback(self, msg):
        if self.waiting:
            return
        cmd = msg.data
        self.get_logger().info(f'Command: {cmd}')
        self.current_command = cmd
        if cmd == 'WAIT':
            self.waiting = True
            t = threading.Thread(target=self.do_wait)
            t.daemon = True
            t.start()

    def do_wait(self):
        self.get_logger().info('Waiting 5 seconds...')
        time.sleep(5)
        self.current_command = 'GO'
        self.waiting = False
        self.get_logger().info('Resuming!')

    def control_loop(self):
        twist = Twist()
        cmd = self.current_command
        if   cmd == 'GO':    twist.linear.x =  0.5; twist.angular.z =  0.0
        elif cmd == 'STOP':  twist.linear.x =  0.0; twist.angular.z =  0.0
        elif cmd == 'LEFT':  twist.linear.x =  0.3; twist.angular.z =  0.8
        elif cmd == 'RIGHT': twist.linear.x =  0.3; twist.angular.z = -0.8
        elif cmd == 'SLOW':  twist.linear.x =  0.15; twist.angular.z = 0.0
        elif cmd == 'WAIT':  twist.linear.x =  0.0; twist.angular.z =  0.0
        else:                twist.linear.x =  0.0; twist.angular.z =  0.0
        self.cmd_pub.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = RobotController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
